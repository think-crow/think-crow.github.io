# Welcome to the hugo-ladder docs!

## Basic Usage

* [Quick Start](quick-start.md)
* [Configurations](configurations.md)

## Extra Guides

* [Multi Language](multi-language.md)
* [Comment System](comment-system.md)
* [Analytics](analytics.md)
* [Analytics Umami](umami.md)

