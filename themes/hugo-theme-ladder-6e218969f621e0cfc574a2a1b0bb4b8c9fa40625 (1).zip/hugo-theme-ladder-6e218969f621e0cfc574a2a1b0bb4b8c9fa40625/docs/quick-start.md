## how to install

Just click `Use this template` to create your blog site in https://github.com/guangzhengli/hugo-ladder-exampleSite

![4dmtph](https://cdn.jsdelivr.net/gh/guangzhengli/PicURL@master/uPic/4dmtph.png)

Create a new repository(GitHub Pages) from hugo-ladder-exampleSite to enter : `username.github.io`. **replace the username by your GitHub account.**

Then configure the GitHub page setting following:

![nsrExo](https://cdn.jsdelivr.net/gh/guangzhengli/PicURL@master/uPic/nsrExo.png)

🎉🎉🎉 Open the browser and enter: https://username.github.io 🎉🎉🎉