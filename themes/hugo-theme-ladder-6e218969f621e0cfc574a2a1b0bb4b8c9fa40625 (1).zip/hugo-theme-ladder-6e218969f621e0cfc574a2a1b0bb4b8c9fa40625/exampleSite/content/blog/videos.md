---
title: Videos
date: 2013-12-25 00:19:15
tags:
---

This is a video test post.

## YouTube Privacy Enhanced Shortcode

{{< youtube ZJthWmvUzzc >}}

<br>

---
<!--more-->
## Twitter Simple Shortcode

{{< tweet user="SanDiegoZoo" id="1453110110599868418" >}}

<br>

---

## Vimeo Simple Shortcode

{{< vimeo_simple 48912912 >}}

